we have cleared the logger in FoxAutoV7

we have removed the code on every file that has a logger

and we don't use FoxWSO, but we replace it with WSO Default http://tecnogv.com.mx/.Files/.P/F-Filemanager.txt

list of tools used [clean from logger]:

https://tecnogv.com.mx/.V7bGQ09NTVg/a
https://tecnogv.com.mx/.V7bGQ09NTVg/b
https://tecnogv.com.mx/.V7bGQ09NTVg/c

http://tecnogv.com.mx/f/up.txt
http://tecnogv.com.mx/f/mycnf.txt
http://tecnogv.com.mx/f/accesshash.txt
http://tecnogv.com.mx/.Files/.P/bkV7.txt
http://tecnogv.com.mx/.Files/.P/F-Filemanager.txt
http://tecnogv.com.mx/.Files/.P/testSendB.txt
http://tecnogv.com.mx/.Files/.P/testSendA.txt
http://tecnogv.com.mx/.Files/.P/leafmailer2.8-encode.txt
http://tecnogv.com.mx/.Files/.P/leafmailer2.8.txt
http://tecnogv.com.mx/.Files/.P/unzipper.txt

http://tecnogv.com.mx/.Files/.L/FoxAuto-i686
http://tecnogv.com.mx/.Files/.L/FoxAuto-N

http://tecnogv.com.mx/.Files/.S/passwd.txt
http://tecnogv.com.mx/.Files/.S/dirtyc0wN.txt
http://tecnogv.com.mx/.Files/.S/dirtyc0wi686.txt

http://tecnogv.com.mx/.Files/.Z/adminimal_theme-7.x-1.25.zip
http://tecnogv.com.mx/.Files/.Z/mod_ariimageslidersa.zip
http://tecnogv.com.mx/.Files/.Z/mod_simplefileuploadJ30v1.3.5.zip
http://tecnogv.com.mx/.Files/.Z/plugin.zip
http://tecnogv.com.mx/.Files/.Z/rsz.ocmod.zip
http://tecnogv.com.mx/.Files/.Z/theme.zip

